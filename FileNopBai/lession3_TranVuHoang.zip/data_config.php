<?php
$listEmployees = [
    1 => [
        "name"      => "Employee A",
        "salary"    => 15000000,
        "dependent" => 1,
        "baby"      => 0
    ],
    2 => [
        "name"      => "Employee B",
        "salary"    => 25000000,
        "dependent" => 2,
        "baby"      => 1
    ],
    3 => [
        "name"      => "Employee C",
        "salary"    => 40000000,
        "dependent" => 0,
        "baby"      => 2
    ],
    4 => [
        "name"      => "Employee D",
        "salary"    => 42500000,
        "dependent" => 0,
        "baby"      => 0
    ]
];
