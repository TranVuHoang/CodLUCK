<?php
$conn = mysqli_connect('localhost', 'root', '', 'training_php');
mysqli_set_charset($conn, "utf8");
